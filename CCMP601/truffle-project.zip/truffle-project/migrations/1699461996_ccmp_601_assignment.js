var v_Assignment = artifacts.require('./ccmp_601_assignment.sol');
module.exports = function(_deployer) {
  _deployer.deploy(v_Assignment);
};
